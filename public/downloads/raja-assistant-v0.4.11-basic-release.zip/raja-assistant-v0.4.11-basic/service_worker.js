
// Keep the assistant available while the user interacts with the Raja page (for example, changing its language).
if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}
const FLOW_KEY = 'bookingWorkflow';
const AUTH_KEY = 'rajaAssistantAuth';
const API_BASE = 'https://api.railsync.ir';
async function getAuth(){ return (await chrome.storage.local.get(AUTH_KEY))[AUTH_KEY] || null; }

async function requestTabId(msg, sender){
  if(msg?.tabId !== undefined && Number.isInteger(Number(msg.tabId))) return Number(msg.tabId);
  if(Number.isInteger(sender?.tab?.id)) return sender.tab.id;
  const tabs = await chrome.tabs.query({active:true, currentWindow:true});
  const tab = tabs.find(t => t.id != null && isRaja(t.url || ''));
  return tab?.id ?? null;
}

async function ownsTab(tabId){
  const auth = await getAuth();
  if (!auth?.token || !Number.isInteger(tabId) || auth.ownerTabId !== tabId) return false;
  try {
    const tab = await chrome.tabs.get(tabId);
    return isRaja(tab.url || '');
  } catch {
    return false;
  }
}
async function clearAuth(){ await chrome.storage.local.remove(AUTH_KEY); }
async function checkAuth(){
  const auth = await getAuth();
  if(!auth?.token) return {valid:false,message:'برای استفاده از افزونه ابتدا وارد حساب خود شوید.'};

  let response;
  try {
    response = await fetch(API_BASE + '/api/auth/check', {
      method:'GET',
      headers:{authorization:'Bearer '+auth.token}
    });
  } catch {
    return {
      valid:false,
      networkError:true,
      message:'ارتباط با سرور بررسی نشد؛ فرایند رزرو متوقف شد. اتصال اینترنت را بررسی کنید.'
    };
  }

  let data = {};
  try {
    data = await response.json();
  } catch {
    return {
      valid:false,
      networkError:true,
      message:'پاسخ سرور قابل بررسی نیست؛ فرایند رزرو متوقف شد.'
    };
  }

  if (response.status === 401 || (response.ok && data.valid === false)) {
    await clearAuth();
    return {
      valid:false,
      networkError:false,
      message:data.error || 'اشتراک معتبر نیست یا منقضی شده است؛ دوباره وارد شوید.'
    };
  }

  if (!response.ok || data.valid !== true) {
    return {
      valid:false,
      networkError:true,
      message:'سرور موقتاً قادر به تأیید نشست نیست؛ فرایند رزرو متوقف شد. لطفاً بعداً دوباره بررسی کنید.'
    };
  }

  await chrome.storage.local.set({
    [AUTH_KEY]:{
      ...auth,
      token:auth.token,
      username:data.username,
      expiresAt:data.expiresAt,
      checkedAt:Date.now()
    }
  });

  return {valid:true,username:data.username,expiresAt:data.expiresAt};
}
async function requireAuthForWorkflow(){
  const result = await checkAuth();
  if(!result.valid) return result;

  // checkAuth returns validation data, not the stored ownerTabId.
  // Read the stored session so workflow ownership checks remain enforced.
  const storedAuth = await getAuth();
  if(!storedAuth?.token || !Number.isInteger(storedAuth.ownerTabId)){
    return {
      valid:false,
      message:'نشست مالک تب پیدا نشد؛ لطفاً از تب مالک دوباره وارد شوید.'
    };
  }

  return {...result, ownerTabId:storedAuth.ownerTabId};
}
const isRaja = url => /^https:\/\/(www\.)?raja\.ir\//i.test(url || '');
const isPaymentUrl = url => /\/payment(?:\?|\/|$)|gateway|checkout/i.test(url || '');
async function getFlow(){ return (await chrome.storage.local.get(FLOW_KEY))[FLOW_KEY] || null; }
async function setFlow(flow){ await chrome.storage.local.set({[FLOW_KEY]:flow}); }
async function broadcast(message){
  try { const tabs=await chrome.tabs.query({}); for(const tab of tabs){ if(tab.id && isRaja(tab.url)) chrome.tabs.sendMessage(tab.id,{type:'STATUS',...message}).catch(()=>{}); } } catch{}
  try { chrome.runtime.sendMessage({type:'UI_STATUS',...message}).catch(()=>{}); } catch{}
}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  (async()=>{
    if(msg.type==='AUTH_LOGIN'){
      const username=String(msg.username||'').trim(), password=String(msg.password||'');
      if(!username||!password){sendResponse({ok:false,valid:false,message:'نام کاربری و رمز عبور را وارد کنید.'});return;}
      try{
        const response=await fetch(API_BASE+'/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username,password})});
        const data=await response.json().catch(()=>({}));
        if(!response.ok||!data.token){sendResponse({ok:false,valid:false,message:data.error||'ورود انجام نشد؛ اطلاعات را بررسی کنید.'});return;}
        const ownerTabId = await requestTabId(msg, sender);
        if (!Number.isInteger(ownerTabId)) {
          sendResponse({ok:false,valid:false,message:'برای ورود، ابتدا سایت رجا را در همین تب باز کنید.'});
          return;
        }
        let ownerTab;
        try { ownerTab = await chrome.tabs.get(ownerTabId); } catch {}
        if (!ownerTab || !isRaja(ownerTab.url || '')) {
          sendResponse({ok:false,valid:false,message:'برای ورود، ابتدا سایت رجا را در همین تب باز کنید.'});
          return;
        }
        const existingAuth = await getAuth();
        if (existingAuth?.token && existingAuth.ownerTabId !== ownerTabId) {
          sendResponse({ok:false,valid:false,message:'حساب در تب دیگری فعال است؛ ابتدا از همان تب خارج شوید یا آن را ببندید.'});
          return;
        }
        await chrome.storage.local.set({[AUTH_KEY]:{token:data.token,username:data.username,expiresAt:data.expiresAt,checkedAt:Date.now(),ownerTabId}});
        await chrome.alarms.create('raja-auth-heartbeat', { periodInMinutes: 1 });
        sendResponse({ok:true,valid:true,username:data.username,expiresAt:data.expiresAt});return;
      }catch{sendResponse({ok:false,valid:false,message:'ارتباط با سرور برقرار نشد؛ اتصال اینترنت را بررسی کنید.'});return;}
    }
    if(msg.type==='AUTH_STATUS'){
      const auth = await getAuth();
      const tabId = await requestTabId(msg, sender);
      if(!auth?.token){
        sendResponse({valid:false,message:'برای استفاده از افزونه ابتدا وارد حساب خود شوید.'});return;
      }
      if(!Number.isInteger(tabId) || auth.ownerTabId !== tabId || !(await ownsTab(tabId))){
        sendResponse({valid:false,ownerMismatch:true,message:'این حساب در تب دیگری فعال است؛ برای استفاده از افزونه به تب مالک حساب برگردید.'});return;
      }
      const result=await checkAuth();sendResponse(result);return;
    }
    if(msg.type==='NETWORK_OFFLINE'){
      const tabId=sender.tab?.id;
      const auth=await getAuth();
      if(!auth?.token || tabId==null || auth.ownerTabId!==tabId || !(await ownsTab(tabId))){
        sendResponse({ok:false});return;
      }
      const flow=await getFlow();
      if(flow?.active && flow.tabId===tabId){
        flow.active=false;
        flow.stage='auth-network-error';
        flow.stoppedAt=Date.now();
        await setFlow(flow);
        await chrome.tabs.sendMessage(tabId,{type:'STOP'}).catch(()=>{});
        await broadcast({running:false,message:'اتصال اینترنت قطع شد؛ فرایند رزرو متوقف شد. نشست حساب حفظ شده است.'});
      }
      sendResponse({ok:true});return;
    }
    if(msg.type==='NETWORK_ONLINE'){
      const tabId=sender.tab?.id;
      const auth=await getAuth();
      if(!auth?.token || tabId==null || auth.ownerTabId!==tabId || !(await ownsTab(tabId))){
        sendResponse({ok:false});return;
      }
      const result=await checkAuth();
      await broadcast({
        running:false,
        message:result.valid
          ? 'اتصال اینترنت برقرار شد و نشست حساب تأیید شد؛ رزرو به‌صورت خودکار از سر گرفته نمی‌شود.'
          : result.message || 'اتصال برقرار شد، اما اعتبار نشست تأیید نشد.'
      });
      sendResponse({ok:result.valid,valid:result.valid,message:result.message||''});return;
    }
    if(msg.type==='CHECK_OWNER'){
      const tabId = Number(msg.tabId);
      const auth = await getAuth();
      if(!auth?.token || !Number.isInteger(tabId) || auth.ownerTabId !== tabId || !(await ownsTab(tabId))){
        sendResponse({ok:false,message:'فقط تب مالک حساب می‌تواند این کار را انجام دهد.'});return;
      }
      sendResponse({ok:true});return;
    }
    if(msg.type==='SAVE_SETTINGS'){
      const tabId = Number(msg.tabId);
      const auth = await getAuth();
      if(!auth?.token || !Number.isInteger(tabId) || auth.ownerTabId !== tabId || !(await ownsTab(tabId))){
        sendResponse({ok:false,message:'فقط تب مالک حساب می‌تواند تنظیمات را ذخیره کند.'});return;
      }
      const {settings,profiles,contactPhone} = msg;
      await chrome.storage.local.set({settings,profiles,contactPhone});
      sendResponse({ok:true});return;
    }
    if(msg.type==='AUTH_LOGOUT'){
      const auth = await getAuth();
      const tabId = await requestTabId(msg, sender);
      if(auth?.token && (
        auth.ownerTabId == null ||
        tabId === null ||
        auth.ownerTabId !== tabId ||
        !Number.isInteger(tabId)
      )){
        sendResponse({ok:false,valid:true,message:'فقط تب مالک می‌تواند از حساب خارج شود.'}); return;
      }
      if(auth?.token){
        let ownerTab;
        try { ownerTab = await chrome.tabs.get(tabId); } catch {}
        if(!ownerTab || !isRaja(ownerTab.url || '')){
          sendResponse({ok:false,valid:true,message:'برای خروج از حساب، از تب مالک در سایت رجا استفاده کنید.'}); return;
        }
      }
      if(auth?.token){
        try {
          await fetch(API_BASE + '/api/auth/logout', {
            method: 'POST',
            headers: { authorization: 'Bearer ' + auth.token }
          });
        } catch {}
      }
      await clearAuth();
      await chrome.alarms.clear('raja-auth-heartbeat');
      const flow=await getFlow();if(flow?.active){flow.active=false;flow.stage='stopped';flow.stoppedAt=Date.now();await setFlow(flow);}
      await broadcast({running:false,message:'از حساب خارج شدید.'});
      sendResponse({ok:true,valid:false,message:'از حساب خارج شدید.'});return;
    }
    if(msg.type==='START_WORKFLOW'){
      const auth=await requireAuthForWorkflow();
      if(!auth.valid){sendResponse({ok:false,message:auth.message});return;}
      const tabId=Number(msg.tabId);
      if(!Number.isInteger(tabId)) { sendResponse({ok:false,message:'تب رجا شناسایی نشد.'}); return; }
      if(auth.ownerTabId !== tabId || !(await ownsTab(tabId))) { sendResponse({ok:false,message:'شروع فرایند فقط از تب مالک در سایت رجا مجاز است.'}); return; }
      const flow={active:true,tabId,settings:msg.settings||{},startedAt:Date.now(),lastHandledUrl:'',stage:'starting'};
      await setFlow(flow); await broadcast({running:true,message:'رزرو آغاز شد؛ مراحل بعدی خودکار ادامه پیدا می‌کنند.'});
      sendResponse({ok:true}); return;
    }
    if(msg.type==='FLOW_STARTED'){
      const auth=await requireAuthForWorkflow();
      if(!auth.valid){sendResponse({ok:false,message:auth.message});return;}
      const tabId=sender.tab?.id;
      if(tabId==null) { sendResponse({ok:false}); return; }
      if(auth.ownerTabId !== tabId || !(await ownsTab(tabId))) { sendResponse({ok:false,message:'این نشست متعلق به تب دیگری است یا تب در سایت رجا نیست.'}); return; }
      const currentFlow=await getFlow();
      if(currentFlow?.active && currentFlow.tabId !== tabId) { sendResponse({ok:false,message:'فرایند رزرو در تب دیگری فعال است.'}); return; }
      const flow={active:true,tabId,settings:msg.settings||{},startedAt:Date.now(),lastHandledUrl:sender.tab.url||'',stage:'search'};
      await setFlow(flow); await broadcast({running:true,message:'رزرو آغاز شد؛ مراحل بعدی پس از بارگذاری صفحات به‌صورت خودکار اجرا می‌شوند.'}); sendResponse({ok:true}); return;
    }
    if(msg.type==='FLOW_STOPPED'){
      console.warn('[Raja Diagnostic] FLOW_STOPPED received', {
        message: msg.message || '',
        senderUrl: sender.tab?.url || 'extension/context',
        senderTabId: sender.tab?.id ?? null,
        time: new Date().toISOString()
      });
      const flow = await getFlow();
      const tabId = sender.tab?.id;

      if (flow?.active && (
        tabId == null ||
        flow.tabId !== tabId ||
        !(await ownsTab(tabId))
      )) {
        sendResponse({ok:false,message:'فقط تب مالک می‌تواند وضعیت فرایند را تغییر دهد.'});
        return;
      }

      if (!flow?.active) {
        sendResponse({ok:true});
        return;
      }

      flow.active = false;
      flow.stage = 'stopped';
      flow.stoppedAt = Date.now();
      await setFlow(flow);
      await broadcast({running:false,message:msg.message||'فرایند رزرو متوقف شد.'});
      sendResponse({ok:true});
      return;
    }
    if(msg.type==='UPDATE_INTERVAL'){
      const auth=await getAuth();
      const flow=await getFlow();
      const tabId=await requestTabId(msg,sender);
      if(!auth?.token || tabId===null || auth.ownerTabId!==tabId || !(await ownsTab(tabId))){
        sendResponse({ok:false,message:'فقط تب مالک حساب در سایت رجا می‌تواند تنظیمات را تغییر دهد.'}); return;
      }
      if(flow?.active && flow.tabId!==tabId){
        sendResponse({ok:false,message:'هنگام اجرای رزرو، فقط تب مالک می‌تواند تنظیمات را تغییر دهد.'}); return;
      }
      const interval=Math.max(1,Math.min(30,Number(msg.interval)||5));
      const saved=await chrome.storage.local.get('settings');
      await chrome.storage.local.set({settings:{...(saved.settings||{}),interval}});
      if(flow?.active){flow.settings={...(flow.settings||{}),interval};await setFlow(flow);chrome.tabs.sendMessage(flow.tabId,{type:'UPDATE_INTERVAL',interval}).catch(()=>{});}
      sendResponse({ok:true,interval});return;
    }
    if(msg.type==='GET_FLOW'){
      const auth = await getAuth();
      const tabId = sender.tab?.id;

      if (!auth?.token || tabId == null || auth.ownerTabId !== tabId || !(await ownsTab(tabId))) {
        sendResponse(null);
        return;
      }

      sendResponse(await getFlow());
      return;
    }
    if(msg.type==='STOP_FLOW'){
      const flow=await getFlow();
      const tabId=await requestTabId(msg,sender);
      const auth=await getAuth();
      if(auth?.token && (tabId===null || auth.ownerTabId!==tabId || !(await ownsTab(tabId)))){
        sendResponse({ok:false,message:'فقط تب مالک حساب در سایت رجا می‌تواند فرایند را متوقف کند.'}); return;
      }
      if(flow?.active && (tabId===null || flow.tabId!==tabId)){
        sendResponse({ok:false,message:'فقط تب مالک می‌تواند فرایند رزرو را متوقف کند.'}); return;
      }
      if(flow){flow.active=false;flow.stage='stopped';flow.stoppedAt=Date.now();await setFlow(flow); if(flow.tabId!=null) chrome.tabs.sendMessage(flow.tabId,{type:'STOP'}).catch(()=>{});}
      await broadcast({running:false,message:'فرایند رزرو به درخواست شما متوقف شد.'}); sendResponse({ok:true,message:'فرایند رزرو متوقف شد.'}); return;
    }
    if(msg.type==='PREPARE_RETRY'){
      const flow=await getFlow();
      const tabId=await requestTabId(msg,sender);
      if(!flow?.active){
        sendResponse({ok:false,message:'فرایند فعالی برای تلاش مجدد وجود ندارد.'}); return;
      }
      if(tabId===null || flow.tabId!==tabId || !(await ownsTab(tabId))){
        sendResponse({ok:false,message:'فقط تب مالک می‌تواند تلاش مجدد را انجام دهد.'}); return;
      }
      flow.lastHandledUrl='';flow.stage='search-retry';flow.retryCount=(flow.retryCount||0)+1;flow.lastRetryAt=Date.now();await setFlow(flow);
      sendResponse({ok:true}); return;
    }
    if(msg.type==='STATUS'){
      const auth = await getAuth();
      const tabId = sender.tab?.id;

      if (!auth?.token || tabId == null || auth.ownerTabId !== tabId || !(await ownsTab(tabId))) {
        sendResponse({ok:false,message:'فقط تب مالک می‌تواند وضعیت فرایند را گزارش کند.'});
        return;
      }

      await broadcast({running:!!msg.running,message:msg.message||''});
      sendResponse({ok:true});
      return;
    }
    sendResponse({ok:false});
  })().catch(()=>sendResponse({ok:false}));
  return true;
});


async function runAuthHeartbeat(){
  const auth = await getAuth();
  if(!auth?.token) {
    await chrome.alarms.clear('raja-auth-heartbeat');
    return;
  }

  const result = await checkAuth();

  if(!result.valid){
    const flow = await getFlow();
    if(flow?.active){
      flow.active = false;
      flow.stage = result.networkError ? 'auth-network-error' : 'auth-expired';
      flow.stoppedAt = Date.now();
      await setFlow(flow);
    }

    await broadcast({
      running: false,
      message: result.message || 'اعتبار نشست تأیید نشد؛ فرایند رزرو متوقف شد.'
    });
    return;
  }

  const flow = await getFlow();
  if(flow?.active){
    await broadcast({running:true,message:'اعتبار نشست تأیید شد.'});
  }
}

chrome.alarms.onAlarm.addListener(alarm => {
  if(alarm.name === 'raja-auth-heartbeat'){
    runAuthHeartbeat().catch(() => {});
  }
});

async function ensureAuthHeartbeat(){
  const auth = await getAuth();
  if(auth?.token){
    await chrome.alarms.create('raja-auth-heartbeat', { periodInMinutes: 1 });
  }
}

chrome.runtime.onStartup.addListener(() => {
  ensureAuthHeartbeat().catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{
  if(changeInfo.status!=='complete' || !isRaja(tab.url)) return;
  (async()=>{
    const flow=await getFlow(); if(!flow?.active || flow.tabId!==tabId) return;
    const auth=await checkAuth();
    if(!auth.valid){
      flow.active=false;
      flow.stage=auth.networkError?'auth-network-error':'auth-expired';
      flow.stoppedAt=Date.now();
      await setFlow(flow);
      await broadcast({
        running:false,
        message:auth.message||'اعتبار اشتراک تأیید نشد؛ وارد حساب شوید.'
      });
      return;
    }
    if(isPaymentUrl(tab.url)){
      flow.active=false; flow.stage='gateway'; flow.lastHandledUrl=tab.url; await setFlow(flow);
      await broadcast({running:false,message:'به صفحه انتخاب درگاه رسیدید. ادامه کار و پرداخت نهایی دستی است.'}); return;
    }
    if(flow.lastHandledUrl===tab.url) return;
    flow.lastHandledUrl=tab.url; flow.stage='continuing'; await setFlow(flow);
    const send=()=>chrome.tabs.sendMessage(tabId,{type:'AUTO_CONTINUE',settings:flow.settings}).catch(()=>null);
    // Content scripts are usually ready by document_idle; retry once if navigation is still settling.
    let result=await send(); if(!result){setTimeout(()=>send(),900);}
  })().catch(()=>{});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  (async () => {
    const auth = await getAuth();
    const wasOwner = !!auth?.token && auth.ownerTabId === tabId;
    const flow = await getFlow();

    if (flow?.active && (wasOwner || flow.tabId === tabId)) {
      flow.active = false;
      flow.stage = 'owner-tab-closed';
      flow.stoppedAt = Date.now();
      await setFlow(flow);
      if (flow.tabId != null) {
        chrome.tabs.sendMessage(flow.tabId, {type:'STOP'}).catch(() => {});
      }
      await broadcast({
        running: false,
        message: 'تب مالک بسته شد؛ فرایند رزرو متوقف شد.'
      });
    }

    if (wasOwner) {
      await clearAuth();
      await chrome.alarms.clear('raja-auth-heartbeat');
      try {
        fetch(API_BASE + '/api/auth/logout', {
          method: 'POST',
          headers: { authorization: 'Bearer ' + auth.token }
        }).catch(() => {});
      } catch {}
    }
  })().catch(() => {});
});

chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.get(FLOW_KEY).then(d=>{if(d[FLOW_KEY]?.active){d[FLOW_KEY].active=false;d[FLOW_KEY].stage='interrupted';chrome.storage.local.set({[FLOW_KEY]:d[FLOW_KEY]});}});});
