(() => {
  if (window.__safirRailLoaded) return;
  window.__safirRailLoaded = true;

  let running = false;
  let liveIntervalSeconds = 5;
  let intervalRevision = 0;
  const clampInterval = value => Math.max(1, Math.min(30, Number(value) || 5));
  async function waitLiveInterval(fallbackSeconds) {
    let revision = intervalRevision;
    let seconds = clampInterval(liveIntervalSeconds || fallbackSeconds);
    let started = Date.now();
    while (running) {
      if (revision !== intervalRevision) { revision = intervalRevision; seconds = clampInterval(liveIntervalSeconds); started = Date.now(); }
      if (Date.now() - started >= seconds * 1000) return true;
      await sleep(100);
    }
    return false;
  }
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const latin = s => String(s || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  const visible = el => !!(el && el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).display !== 'none');
  const all = (sel, root=document) => [...root.querySelectorAll(sel)].filter(visible);
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const log = message => { try { chrome.runtime.sendMessage({ type: 'STATUS', running, message }); } catch {} };
  const textOf = el => norm(el?.innerText || el?.textContent || '');
  const setValue = (el, value) => {
    if (!el || value == null || !visible(el)) return false;
    try {
      el.focus();
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, String(value)); else el.value = String(value);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      return true;
    } catch { return false; }
  };
  const isResultsUrl = () => /\/search(?:\?|$)/i.test(location.pathname + location.search);
  // A .train-result container can exist before its booking button is rendered.
  // Wait for an actionable booking button or the continue-purchase control.
  const hasResultControls = () =>
    !!all('.train-result button.lock-btn, button.lock-btn').find(button => !button.disabled) ||
    !!clickableText(/ادامه\s*خرید|ادامه\s*فرایند\s*خرید|continue\s*purchase/i);
  const isResultsPage = () => isResultsUrl() && hasResultControls();
  function hasExplicitNoTicketMessage() {
    const body = norm(document.body?.innerText || '');
    return /برای مسیر شما در این تاریخ قطار یافت نشد|قطاری برای مسیر.*پیدا نشد|بلیتی برای این مسیر.*پیدا نشد|موردی برای نمایش وجود ندارد|نتیجه.?ای یافت نشد/.test(body);
  }
  async function waitForResultsReady(timeoutMs=18000) {
    const started=Date.now();
    while (Date.now()-started < timeoutMs) {
      if (hasResultControls()) return true;
      // If Raja has already rendered its explicit no-ticket message, don't burn
      // the full 18-second AJAX safety timeout before using the chosen interval.
      if (hasExplicitNoTicketMessage()) return false;
      await sleep(200);
    }
    return false;
  }
  const isPassengerPage = () => /registerticket/i.test(location.href) || !!document.querySelector('.passenger-registor');
  const humanGate = () => {
    const url = location.href;
    const text = norm(document.body?.innerText).slice(0, 12000);
    // Only visible security challenges should pause the workflow.
    // Payment pages remain manual, and hidden template fields must not stop search retries.
    const visibleChallenge = selector =>
      [...document.querySelectorAll(selector)].some(el => visible(el));
    const actualCaptcha = visibleChallenge(
      'iframe[src*="captcha" i], .g-recaptcha, [id*="captcha" i], input[name*="captcha" i]'
    );
    const actualOtp = visibleChallenge(
      'input[autocomplete="one-time-code"], input[name*="otp" i], input[id*="otp" i]'
    );
    return actualCaptcha || actualOtp ||
      /\/payment(?:\?|\/|$)|gateway|checkout/i.test(url) ||
      (/کد امنیتی|captcha/.test(text) && actualCaptcha);
  };
  const notify = (message, ok=false, keepFlow=false) => {
    running = keepFlow;
    try {
      if (!keepFlow) chrome.runtime.sendMessage({type:'FLOW_STOPPED', message});
      else chrome.runtime.sendMessage({type:'STATUS', running:true, message});
    } catch {}
    return { ok, message };
  };
  const clickableText = (pattern, root=document) =>
    all('button, a, [role="button"], input[type="button"], input[type="submit"]', root)
      .find(el => pattern.test(textOf(el) || el.value || el.getAttribute('aria-label') || '') && !el.disabled);

  function relatedText(el) {
    const chunks = [];
    let n = el;
    for (let i = 0; n && i < 4; i++, n = n.parentElement) chunks.push(textOf(n).slice(0, 300));
    return chunks.join(' ');
  }
  function findStationInput(kind) {
    const componentName = kind === 'origin' ? 'fromStation' : 'toStation';
    const component = document.querySelector(
      `app-stations[name="${componentName}"]`
    );

    if (!component) return null;
    return component.querySelector('input[role="combobox"]');
  }

  async function chooseAutocomplete(input, value) {
    if (!input || !value?.trim()) return false;

    const component = input.closest('app-stations');
    if (!component) return false;

    const normalize = text =>
      norm(text)
        .replace(/[يى]/g, 'ی')
        .replace(/ك/g, 'ک')
        .replace(/\s+/g, ' ')
        .trim();

    const wanted = normalize(value);
    const nativeSetter = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      'value'
    )?.set;

    if (!nativeSetter) return false;

    input.focus();
    nativeSetter.call(input, '');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(150);

    nativeSetter.call(input, value.trim());
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(800);

    const options = [...component.querySelectorAll('.ng-option')]
      .filter(option =>
        option.getClientRects().length > 0 &&
        !option.classList.contains('ng-option-disabled')
      );

    const exactOption = options.find(option => {
      const label = normalize(option.innerText || option.textContent || '');
      return label === wanted;
    });

    if (!exactOption) {
      log(`پیشنهاد دقیق «${value}» در فهرست ایستگاه‌های رجا پیدا نشد.`);
      return false;
    }

    exactOption.click();
    await sleep(350);

    const selectedLabel =
      component.querySelector('.ng-value-label') ||
      component.querySelector('.ng-value');

    const selectedText = normalize(
      selectedLabel?.innerText || selectedLabel?.textContent || ''
    );

    if (
      selectedText === wanted ||
      selectedText.replace(/^(?:مبدأ|مبدا|مقصد)\s*\(?/, '')
        .replace(/\)$/, '') === wanted
    ) return true;

    log(`انتخاب ایستگاه «${value}» تأیید نشد.`);
    return false;
  }

  function findDateInput() {
    const inputs = all('input:not([type=hidden])');
    return inputs.find(el => /تاریخ|date|move.?date|travel.?date/i.test([
      el.placeholder, el.title, el.name, el.id, el.getAttribute('aria-label'),
      el.getAttribute('formcontrolname')
    ].join(' '))) ||
    inputs.find(el => /تاریخ رفت|تاریخ حرکت|تاریخ سفر|تاریخ/.test(relatedText(el)));
  }
  function findPassengerControl() {
    const candidates = all('select, input:not([type=hidden]), button, [role="combobox"], [role="button"]');
    // Prefer a control whose own label/text indicates passenger count; do not match
    // every field merely because the entire booking form mentions passengers.
    const direct = candidates.find(el => /تعداد مسافر|تعداد نفر|passenger count|number of passengers/i.test([
      el.getAttribute('aria-label'), el.title, el.name, el.id, el.placeholder, el.getAttribute('formcontrolname')
    ].join(' ')));
    if (direct) return direct;
    return candidates.find(el => {
      const own = norm(el.matches('input,select') ? [el.value, el.placeholder, el.title].join(' ') : textOf(el));
      return /^(?:[۰-۹0-9]+\s*)?(?:مسافر|مسافران|نفر)(?:\s*[▼⌄▾])?$/.test(own) || /^(?:[۰-۹0-9]+\s*)مسافر/.test(own);
    });
  }
  async function setPassengerCount(count) {
    const control = findPassengerControl();
    if (!control) return false;
    if (control.tagName === 'SELECT') {
      const wanted = String(count);
      const option = [...control.options].find(o => latin(o.value) === wanted || latin(o.textContent).trim().startsWith(wanted));
      if (!option) return false;
      control.value = option.value;
      control.dispatchEvent(new Event('input', {bubbles:true}));
      control.dispatchEvent(new Event('change', {bubbles:true}));
      return true;
    }
    control.click();
    await sleep(200);
    const option = all('[role="option"], li, button, a, [role="menuitem"]')
      .find(el => new RegExp(`^\\s*${count}\\s*(مسافر|نفر|بزرگسال)?\\s*$`).test(textOf(el)) || textOf(el) === String(count));
    if (option) { option.click(); return true; }
    // Try a numeric text input if this is genuinely a passenger count input.
    if (control.matches('input')) return setValue(control, count);
    return false;
  }
  function normalizeJalaliDate(raw) {
    const value = latin(raw).trim().replace(/[.-]/g, '/');
    const match = value.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
    if (!match) return null;
    const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
    const maxDay = month <= 6 ? 31 : month <= 11 ? 30 : 30;
    if (year < 1300 || year > 1500 || month < 1 || month > 12 || day < 1 || day > maxDay) return null;
    return `${year}${String(month).padStart(2, '0')}${String(day).padStart(2, '0')}`;
  }
  const stationIds = new Map();
  let stationIdsPromise = null;

  async function loadStationIds() {
    if (!stationIdsPromise) {
      stationIdsPromise = fetch(chrome.runtime.getURL('stations.json'))
        .then(response => {
          if (!response.ok) throw new Error('بارگذاری فهرست ایستگاه‌ها ناموفق بود.');
          return response.json();
        })
        .then(items => {
          if (!Array.isArray(items)) throw new Error('ساختار فهرست ایستگاه‌ها معتبر نیست.');
          for (const item of items) {
            if (item?.Name == null || item?.Code == null) continue;
            const key = norm(String(item.Name)).replace(/ي/g, 'ی').replace(/ك/g, 'ک');
            if (key && !stationIds.has(key)) stationIds.set(key, String(item.Code));
          }
          return stationIds;
        })
        .catch(error => {
          stationIdsPromise = null;
          throw error;
        });
    }
    return stationIdsPromise;
  }

  function stationId(name) {
    const key = norm(name).replace(/ي/g, 'ی').replace(/ك/g, 'ک');
    return stationIds.get(key) || null;
  }
  async function startFromSearchForm(settings) {
    const dateCode = normalizeJalaliDate(settings.dateJalali);
    const count = Math.max(1, Math.min(6, Number.parseInt(latin(settings.passengers || '1'), 10) || 1));
    if (!settings.origin?.trim() || !settings.destination?.trim()) return notify('مبدأ و مقصد را وارد کنید.', false);
    if (norm(settings.origin) === norm(settings.destination)) return notify('مبدأ و مقصد نمی‌توانند یکسان باشند.', false);
    if (!dateCode) return notify('تاریخ شمسی معتبر نیست. نمونه: ۱۴۰۵/۰۷/۲۱.', false);

    // For the confirmed Tehran -> Mashhad route, use Raja's native search URL.
    // This avoids trying to set the read-only datepicker input through the DOM.
    try {
      await loadStationIds();
    } catch (error) {
      log('فهرست شناسه‌های ایستگاه‌ها بارگذاری نشد؛ از روش انتخاب ایستگاه در سایت استفاده می‌شود.');
    }
    const originId = stationId(settings.origin);
    const destinationId = stationId(settings.destination);
    if (originId && destinationId) {
      const params = new URLSearchParams({
        adult: String(count), child: '0', infant: '0', movetype: '1', ischarter: 'false',
        fs: originId, ts: destinationId,
        godate: latin(dateCode).replace(/\D/g, ''),
        tickettype: 'Family',
        returndate: '', numberpassenger: String(count), mode: 'Train',
        desctravel: `قطار ${settings.origin} به ${settings.destination}`
      });
      const target = `${location.origin}/search?${params.toString()}`;
      log(`در حال بازکردن جست‌وجوی مستقیم رجا برای ${settings.origin} به ${settings.destination} در تاریخ ${settings.dateJalali}.`);
      location.assign(target);
      return {ok:true, message:'جست‌وجوی مستقیم رجا با تاریخ استاندارد و تعداد مسافران در حال بازشدن است.'};
    }

    // For other routes, retain the existing live station-autocomplete flow.
    // If we're on another page, go to Raja's search page first and resume on load.
    if (!/^\/$/.test(location.pathname) || isResultsUrl()) {
      log('در حال بازکردن فرم اصلی جست‌وجوی رجا برای انتخاب ایستگاه‌های واقعی سایت…');
      location.assign(`${location.origin}/`);
      return {ok:true,message:'فرم جست‌وجوی رجا باز می‌شود؛ پس از بارگذاری، مبدأ و مقصد از فهرست خود سایت انتخاب می‌شوند.'};
    }
    const originInput = findStationInput('origin');
    const destinationInput = findStationInput('destination');
    if (!originInput || !destinationInput) return notify('فرم انتخاب مبدأ و مقصد در صفحه اصلی رجا پیدا نشد. صفحه را بررسی کن؛ هیچ شناسه ایستگاهی حدس زده نشد.', false);
    const originChosen = await chooseAutocomplete(originInput, settings.origin.trim());
    const destinationChosen = await chooseAutocomplete(destinationInput, settings.destination.trim());
    if (!originChosen || !destinationChosen) return notify('انتخاب مبدأ یا مقصد از فهرست ایستگاه‌های رجا تأیید نشد. از پیشنهادهای خود سایت یکی را انتخاب کن.', false);
    const dateInput = findDateInput();
    if (dateInput && !setValue(dateInput, settings.dateJalali)) return notify('فیلد تاریخ حرکت در فرم رجا پیدا شد اما قابل تنظیم نبود؛ تاریخ را در خود سایت انتخاب کن.', false);
    if (!await setPassengerCount(count)) log('تعداد مسافران به‌صورت خودکار تنظیم نشد؛ لطفاً مقدار آن را در فرم رجا بررسی کن.');
    await sleep(300);
    const searchButton = clickableText(/جست.?وجو|جستجو|نمایش بلیت|search tickets|search trains/i);
    if (!searchButton) return notify('دکمه جست‌وجوی فرم رجا شناسایی نشد. مبدأ، مقصد و تاریخ در فرم آماده‌اند؛ جست‌وجو را در خود سایت بزن.', false);
    log(`جست‌وجوی رجا برای ${settings.origin} به ${settings.destination} در تاریخ ${settings.dateJalali} آغاز می‌شود.`);
    searchButton.click();
    return {ok:true,message:'فرم جست‌وجوی رجا با ایستگاه‌های انتخاب‌شده از فهرست خود سایت ارسال شد.'};
  }
  function playTicketFoundAlarm() {
    try {
      const alarm = new Audio(chrome.runtime.getURL('sounds/ticket-found.mp3'));
      alarm.volume = 1;
      alarm.play().catch(error => {
        log('پخش آلارم انجام نشد؛ تنظیمات صدای مرورگر را بررسی کنید.');
        console.warn('[Raja Alarm] Playback failed:', error);
      });
    } catch (error) {
      console.warn('[Raja Alarm] Could not start audio:', error);
    }
  }

  function trainMatchesFilters(card, settings = {}) {
    const normFa = value => latin(norm(value))
      .normalize('NFC')
      .replace(/[يى]/g, 'ی')
      .replace(/ك/g, 'ک');

    const wagon = normFa(card.querySelector('.wagon-type')?.innerText || '');
    const company = normFa(card.querySelector('.owner-name')?.innerText || '');
    const name = normFa(card.querySelector('.train-name')?.innerText || '');
    const priceText = latin(card.querySelector('.price')?.innerText || '').replace(/[^\d]/g, '');
    const price = priceText ? Number(priceText) : null;
    const status = normFa(card.querySelector('.capacity-title')?.innerText || '');
    const cardText = normFa(card.innerText || '');

    const wagonFilter = normFa(settings.wagonFilter || '');
    if (wagonFilter && !wagon.includes(wagonFilter)) return {ok:false, reason:'نوع واگن'};

    const companyFilter = normFa(settings.trainCompany || '');
    if (companyFilter && !company.includes(companyFilter)) return {ok:false, reason:'شرکت قطار'};

    const starFilter = latin(settings.starFilter || '').replace(/[^\d]/g, '');
    if (starFilter) {
      const starPattern = new RegExp(`(?:^|\\D)${starFilter}\\s*ستاره`);
      if (!starPattern.test(name) && !starPattern.test(cardText)) {
        return {ok:false, reason:'درجه ستاره'};
      }
    }

    const minPriceText = latin(settings.minPrice || '').replace(/[^\d]/g, '');
    const maxPriceText = latin(settings.maxPrice || '').replace(/[^\d]/g, '');
    if ((minPriceText || maxPriceText) && price === null) {
      return {ok:false, reason:'قیمت نامشخص'};
    }
    if (minPriceText && price < Number(minPriceText)) return {ok:false, reason:'کمتر از حداقل قیمت'};
    if (maxPriceText && price > Number(maxPriceText)) return {ok:false, reason:'بیشتر از حداکثر قیمت'};

    const unavailable = /تمام شد|تکمیل ظرفیت|ناموجود|ظرفیت تکمیل|sold out|unavailable/i.test(status);
    const button = [...card.querySelectorAll('button.lock-btn')]
      .find(candidate => visible(candidate) && !candidate.disabled);

    if (settings.availableOnly !== false && (unavailable || !button)) {
      return {ok:false, reason:'بلیت قابل رزرو نیست'};
    }
    if (unavailable || !button) return {ok:false, reason:'بلیت قابل رزرو نیست'};

    return {ok:true, button, price, company, wagon};
  }

  async function clickFirstAvailableTrain(settings = {}) {
    const continueButton = () => clickableText(/ادامه\s*خرید|ادامه\s*فرایند\s*خرید|continue\s*purchase/i);

    // Never proceed through the purchase step while auto-select is disabled.
    if (settings.autoSelectTrain === false) {
      const matches = all('.train-result').filter(card => trainMatchesFilters(card, settings).ok);
      if (matches.length) {
        playTicketFoundAlarm();
        return {
          ok:false,
          found:true,
          message:`${matches.length} قطار مطابق فیلترها و دارای ظرفیت پیدا شد. انتخاب خودکار خاموش است؛ برای ادامه، قطار را خودتان انتخاب کنید.`
        };
      }
      return {ok:false, found:false, message:'هنوز قطار قابل‌رزرو مطابق همه فیلترها پیدا نشده است.'};
    }

    // If a previous run already selected a train, continue only in auto-select mode.
    const alreadySelected = continueButton();
    if (alreadySelected) {
      alreadySelected.click();
      return {ok:true, message:'دکمه «ادامه خرید» زده شد؛ در حال رفتن به صفحه اطلاعات مسافر.'};
    }

    const matches = all('.train-result')
      .map(card => ({card, match:trainMatchesFilters(card, settings)}))
      .filter(item => item.match.ok);

    const selected = matches[0];
    if (!selected) {
      return {ok:false, found:false, message:'هنوز قطار قابل‌رزرو مطابق همه فیلترها پیدا نشده است.'};
    }

    playTicketFoundAlarm();
    selected.match.button.scrollIntoView({block:'center', behavior:'instant'});
    selected.match.button.click();

    // Wait for Raja to reveal the separate continue-purchase button.
    for (let i = 0; i < 20; i++) {
      await sleep(250);
      const next = continueButton();
      if (next) {
        next.click();
        return {ok:true, message:'قطار مطابق فیلترها انتخاب شد و «ادامه خرید» نیز زده شد؛ در حال رفتن به صفحه اطلاعات مسافر.'};
      }
    }
    return {ok:true, message:'قطار مطابق فیلترها انتخاب شد، اما دکمه «ادامه خرید» پیدا نشد. اگر دکمه سبز را می‌بینید، آن را دستی بزنید.'};
  }
  function fieldByLabel(root, labelPattern) {
    const groups = [...root.querySelectorAll('.form-group, .input-group, .row > div, label')];
    for (const group of groups) {
      const label = textOf(group.querySelector('label, .input-group-text, .control-label')) || textOf(group).slice(0,100);
      if (labelPattern.test(label)) {
        const input = group.querySelector('input:not([type=hidden]), textarea, select');
        if (input && visible(input)) return input;
      }
    }
    return null;
  }
  function passengerCardRoots() {
    const names = all('input[name="pName"]');
    const roots = [];
    for (const input of names) {
      let node = input.parentElement;
      // Find the smallest ancestor containing this passenger's name and family fields,
      // but not the name field of another passenger.
      while (node && node !== document.body) {
        const nameCount = node.querySelectorAll('input[name="pName"]').length;
        const hasFamily = !!node.querySelector('input[name="pFamily"]');
        if (nameCount === 1 && hasFamily) break;
        node = node.parentElement;
      }
      if (node && node !== document.body && !roots.includes(node)) roots.push(node);
    }
    if (roots.length) return roots;
    return all('.passenger-registor');
  }
  async function waitForPassengerForms(expectedCount, timeoutMs=20000) {
    const started = Date.now();
    let lastCount = 0;
    while (Date.now() - started < timeoutMs) {
      lastCount = passengerCardRoots().length;
      // Wait for Raja's dynamically rendered passenger cards and inputs after navigation.
      if (lastCount >= expectedCount) {
        const roots = passengerCardRoots();
        const ready = roots.slice(0, expectedCount).every(card =>
          !!card.querySelector('input[name="pName"]') &&
          !!card.querySelector('input[name="pFamily"]')
        );
        if (ready) return {ready:true, count:lastCount};
      }
      await sleep(300);
    }
    return {ready:false, count:lastCount};
  }
  function fillPassengerForm(profiles, phone, expectedCount) {
    const roots = passengerCardRoots();
    let filled = 0, missing = [];
    if (roots.length < expectedCount) {
      missing.push(`سایت فعلاً فقط ${roots.length} فرم مسافر نشان می‌دهد، اما ${expectedCount} مسافر انتخاب شده‌اند؛ تعداد مسافران را در خود سایت روی ${expectedCount} تنظیم کنید یا فرم افزودن مسافر را باز کنید`);
    }
    roots.slice(0, expectedCount).forEach((card, index) => {
      const p = profiles[index];
      if (!p) { missing.push(`مسافر ${index+1}: پروفایل ذخیره نشده`); return; }
      const name = card.querySelector('input[name="pName"]');
      const family = card.querySelector('input[name="pFamily"]');
      const dob = card.querySelector('input[title*="روز/ماه/سال"], input[placeholder*="1357/11/12"], input[name*="Birth" i], input[id*="Birth" i]') || fieldByLabel(card, /تاریخ تولد|تاریخ.*ولادت|birth.?date/i);
      const national = fieldByLabel(card, /کد ملی|شماره پاسپورت|national/i) || [...card.querySelectorAll('input[maxlength="10"]')].find(visible);
      if (p.firstName && setValue(name, p.firstName)) filled++; else missing.push(`مسافر ${index+1}: نام`);
      if (p.lastName && setValue(family, p.lastName)) filled++; else missing.push(`مسافر ${index+1}: نام خانوادگی`);
      if (p.nationalId && setValue(national, latin(p.nationalId))) filled++; else missing.push(`مسافر ${index+1}: کد ملی/پاسپورت`);
      if (p.birthDate && setValue(dob, latin(p.birthDate).replace(/-/g,'/'))) filled++; else missing.push(`مسافر ${index+1}: تاریخ تولد شمسی`);
    });
    const phoneInputs = all('input').filter(el => /موبایل|شماره همراه|تلفن همراه|mobile|phone/i.test([el.placeholder, el.title, el.name, el.id, el.getAttribute('aria-label'), relatedText(el)].join(' ')));
    if (phone && phoneInputs[0] && setValue(phoneInputs[0], phone)) filled++;
    return {filled, missing, cardCount: roots.length};
  }

  function termsCheckbox() {
    const boxes = all('input[type="checkbox"]');
    for (const box of boxes) {
      const near = relatedText(box);
      if (/شرایط|قوانین|مقررات|اطلاعات.*درست|صحت اطلاعات|قبول دارم|تأیید می‌کنم/.test(near)) return box;
    }
    return null;
  }
  function termsAccepted() { return !!termsCheckbox()?.checked; }
  function waitForTermsConsent() {
    const box = termsCheckbox();
    if (!box || box.dataset.rajaConsentWaiter === '1') return !!box;
    box.dataset.rajaConsentWaiter = '1';
    box.addEventListener('change', () => {
      if (!box.checked) return;
      const pay = clickableText(/^پرداخت$/);
      if (!pay) { notify('تأیید شرایط ثبت شد، اما دکمه پرداخت پیدا نشد؛ مرحله بعد را دستی انجام دهید.', false); return; }
      pay.click();
      notify('تأیید شرایط توسط شما انجام شد؛ در حال رفتن به صفحه انتخاب درگاه. پرداخت نهایی دستی است.', true, true);
    }, {once:true});
    return true;
  }
  async function continueAfterPassengerFill(settings, result) {
    if (!settings.autonext) return notify(`فرم بررسی شد؛ ${result.filled} فیلد تکمیل شد. ادامه خودکار خاموش است؛ مرحله بعد را دستی انجام دهید.`, false);
    if (result.missing.length) return notify(`فرم کامل نیست؛ موارد نیازمند بررسی: ${result.missing.join('، ')}. پس از اصلاح، دوباره «شروع رزرو خودکار» را اجرا کنید.`, false);
    if (!termsAccepted()) {
      if (waitForTermsConsent()) return notify('اطلاعات تکمیل شد. لطفاً تیک تأیید شرایط/صحت اطلاعات را خودتان بزنید؛ پس از تأیید شما، افزونه به‌صورت خودکار به صفحه انتخاب درگاه می‌رود. پرداخت نهایی دستی است.', false, true);
      return notify('اطلاعات تکمیل شد، اما تیک تأیید شرایط قابل شناسایی نیست. لطفاً شرایط را بررسی کنید و مرحله پرداخت را دستی انجام دهید.', false);
    }
    const pay = clickableText(/^پرداخت$|^پرداخت\s*$/);
    if (!pay) return notify('اطلاعات تکمیل شد، اما دکمه «پرداخت» پیدا نشد. لطفاً فرم را بررسی کنید و در صورت معتبر بودن، مرحله بعد را دستی انجام دهید.', false);
    pay.click();
    return notify('فرم تکمیل و دکمه پرداخت ارسال شد؛ در حال رفتن به صفحه انتخاب درگاه. پرداخت نهایی دستی است.', true, true);
  }
  async function handleStart(settings, auto=false) {
    running = true;
    liveIntervalSeconds = clampInterval(settings.interval);
    if (humanGate()) return notify('مرحله امنیتی یا صفحه پرداخت شناسایی شد؛ این بخش را خودتان انجام دهید. CAPTCHA، کد یک‌بارمصرف و پرداخت نهایی دستی باقی می‌مانند.', false);
    if (isPassengerPage()) {
      const data = await chrome.storage.local.get(['profiles','contactPhone','profile']);
      const profiles = data.profiles?.length ? data.profiles : (data.profile ? [data.profile] : []);
      if (!settings.autofill) return notify('تکمیل خودکار خاموش است؛ فرم مسافر را دستی تکمیل کنید.', false);
      const expectedCount = Math.max(1, Math.min(6, Number.parseInt(latin(settings.passengers || '1'), 10) || 1));
      // The registerticket page may finish its document load before Raja renders the
      // passenger form via JavaScript. Wait here so the user does not need to press Start again.
      const formState = await waitForPassengerForms(expectedCount, 20000);
      const result = fillPassengerForm(profiles, data.contactPhone || profiles[0]?.phone || '', expectedCount);
      if (!result.filled && result.missing.length) {
        return notify(`فرم مسافران پس از انتظار ${formState.ready ? 'آماده شد اما' : 'کامل بارگذاری نشد و'} فیلدها شناسایی نشدند (${result.cardCount} فرم از ${expectedCount} مورد انتظار). لطفاً صفحه را بررسی کنید؛ اگر با زدن «شروع رزرو خودکار» دوباره اطلاعات وارد می‌شود، از همین صفحه عکس بفرستید.`, false);
      }
      return continueAfterPassengerFill(settings, result);
    }
    // The /search URL is reached before Raja's AJAX results are necessarily rendered.
    // Do not restart navigation just because result cards are not present yet.
    if (isResultsUrl() && !auto) return await startFromSearchForm(settings);
    if (isResultsUrl()) {
      const ready = await waitForResultsReady(18000);
      if (!ready) {
        const seconds = clampInterval(liveIntervalSeconds);
        log(`نتایج آماده نشد یا بلیت نمایش داده نمی‌شود؛ فاصله بررسی فعلی ${seconds} ثانیه است و حین شمارش معکوس قابل تغییر است.`);
        if (!await waitLiveInterval(seconds)) return {ok:false,message:'جست‌وجوی خودکار متوقف شد.'};
        if (!running) return {ok:false,message:'جست‌وجوی خودکار متوقف شد.'};
        try { await chrome.runtime.sendMessage({type:'PREPARE_RETRY'}); } catch {}
        location.reload();
        return {ok:true,message:`نتایج آماده نبود؛ بررسی مجدد تا ${seconds} ثانیه دیگر انجام می‌شود.`};
      }
      const result = await clickFirstAvailableTrain(settings);
      const autoSelectDisabled = settings.autoSelectTrain === false;

      if (autoSelectDisabled && result.found) {
        const seconds = clampInterval(liveIntervalSeconds);
        log(`${result.message} بررسی مجدد پس از ${seconds} ثانیه انجام می‌شود؛ هیچ دکمه‌ای به‌صورت خودکار کلیک نخواهد شد.`);
        if (!await waitLiveInterval(seconds)) return {ok:false,message:'جست‌وجوی خودکار متوقف شد.'};
        if (!running) return {ok:false,message:'جست‌وجوی خودکار متوقف شد.'};
        try { await chrome.runtime.sendMessage({type:'PREPARE_RETRY'}); } catch {}
        location.reload();
        return {ok:true,message:`قطار مطابق فیلترها پیدا شد؛ انتخاب خودکار خاموش است. جست‌وجوی مجدد پس از ${seconds} ثانیه انجام می‌شود.`};
      }

      if (!result.ok && !result.found && /(?:قطار قابل‌رزرو پیدا نشد|بلیت قابل‌رزرو پیدا نشد|دکمه رزرو هنوز در نتایج آماده نیست|مطابق همه فیلترها)/.test(result.message)) {
        const seconds = clampInterval(liveIntervalSeconds);
        log(`بلیت قابل‌رزرو پیدا نشد؛ فاصله بررسی فعلی ${seconds} ثانیه است و می‌توانی همین حالا آن را تغییر بدهی.`);
        if (!await waitLiveInterval(seconds)) return {ok:false,message:'جست‌وجوی خودکار متوقف شد.'};
        if (!running) return {ok:false,message:'جست‌وجوی خودکار متوقف شد.'};
        try { await chrome.runtime.sendMessage({type:'PREPARE_RETRY'}); } catch {}
        location.reload();
        return {ok:true,message:`بلیت پیدا نشد؛ صفحه برای جست‌وجوی مجدد بارگذاری می‌شود (${seconds} ثانیه).`};
      }
      return notify(result.message, result.ok, result.ok);
    }
    return await startFromSearchForm(settings);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'PING_CONTENT') {
      sendResponse({ok: true, ready: true});
      return true;
    }
    if (msg.type === 'UPDATE_INTERVAL') {
      liveIntervalSeconds = clampInterval(msg.interval);
      intervalRevision++;
      sendResponse({ok:true, interval:liveIntervalSeconds});
      return true;
    }
    if (msg.type === 'STOP') {
      running = false;
      chrome.runtime.sendMessage({type:'FLOW_STOPPED',message:'عملیات متوقف شد.'}).catch(()=>{});
      sendResponse({ok:true, message:'عملیات متوقف شد.'});
      return true;
    }
    if (msg.type !== 'START' && msg.type !== 'AUTO_CONTINUE') return true;
    const isAuto = msg.type === 'AUTO_CONTINUE';
    handleStart(msg.settings || {}, isAuto).then(sendResponse).catch(() => {
      const message='در اجرای مرحله خودکار خطایی رخ داد. فرم را بررسی کنید و اگر ادامه داشت عکس صفحه را بفرستید.';
      chrome.runtime.sendMessage({type:'FLOW_STOPPED',message}).catch(()=>{});
      sendResponse({ok:false, message}); running=false;
    });
    return true;
  });

  window.addEventListener('offline', () => {
    chrome.runtime.sendMessage({type:'NETWORK_OFFLINE'}).catch(() => {});
  });

  window.addEventListener('online', () => {
    chrome.runtime.sendMessage({type:'NETWORK_ONLINE'}).catch(() => {});
  });
})();
