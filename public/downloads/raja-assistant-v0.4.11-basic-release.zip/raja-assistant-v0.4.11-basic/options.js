const $=id=>document.getElementById(id);
chrome.storage.local.get(['profiles','profile','contactPhone','license'],data=>{
 const a=(data.profiles||[])[0]||data.profile||{}, b=(data.profiles||[])[1]||{};
 for(const [id,key] of [['firstName','firstName'],['lastName','lastName'],['nationalId','nationalId'],['birthDate','birthDate'],['firstName2','firstName'],['lastName2','lastName'],['nationalId2','nationalId'],['birthDate2','birthDate']]) $(id).value=(id.endsWith('2')?b[key]:a[key])||'';
 $('phone').value=data.contactPhone||a.phone||'';
 if(data.license){$('plan').value=data.license.plan||'3-day';$('key').value=data.license.key||'';}
});
$('saveProfile').addEventListener('click',()=>{
 const read=(suffix='')=>({firstName:$('firstName'+suffix).value.trim(),lastName:$('lastName'+suffix).value.trim(),nationalId:$('nationalId'+suffix).value.trim(),birthDate:$('birthDate'+suffix).value.trim()});
 const profiles=[read(),read('2')].filter(p=>p.firstName||p.lastName||p.nationalId||p.birthDate);
 const contactPhone=$('phone').value.trim();
 chrome.storage.local.set({profiles,contactPhone},()=>{$('profileMsg').textContent='پروفایل‌ها و شماره تماس روی همین دستگاه ذخیره شدند.';});
});
$('saveLicense').addEventListener('click',()=>{const license={plan:$('plan').value,key:$('key').value.trim(),savedAt:Date.now(),status:'unverified'};chrome.storage.local.set({license},()=>{$('licenseMsg').textContent='انتخاب پلن ذخیره شد؛ اعتبار کلید از سرور بررسی نمی‌شود.';});});
