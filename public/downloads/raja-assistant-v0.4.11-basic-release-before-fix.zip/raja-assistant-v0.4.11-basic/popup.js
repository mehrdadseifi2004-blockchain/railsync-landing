const $ = id => document.getElementById(id);
const defaults = {origin:'تهران',destination:'مشهد',dateJalali:'1405/07/28',passengers:'1',interval:5,autofill:true,autonext:true,wagonFilter:'',trainCompany:'',starFilter:'',minPrice:'',maxPrice:'',availableOnly:true,autoSelectTrain:true};

const authUI = {
  showLogin(message='') {
    $('loginPanel').hidden = false;
    $('appShell').hidden = true;
    $('authMessage').textContent = message;
    $('loginButton').disabled = false;
    $('loginButton').textContent = 'ورود';
  },
  showApp(username='') {
    $('loginPanel').hidden = true;
    $('appShell').hidden = false;
    $('authMessage').textContent = '';
    $('message').textContent = username ? `وارد شده‌اید: ${username}` : '';
  }
};
function runtimeMessage(message) {
  return new Promise(resolve => chrome.runtime.sendMessage(message, response => {
    const err = chrome.runtime.lastError;
    resolve(err ? {ok:false, message:err.message} : (response || {ok:false, message:'پاسخی از افزونه دریافت نشد.'}));
  }));
}
async function refreshAuth() {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  const result = await runtimeMessage({type:'AUTH_STATUS',tabId:tab?.id});
  if (result?.valid) authUI.showApp(result.username || '');
  else authUI.showLogin(result?.message || '');
}
$('loginButton').addEventListener('click', async () => {
  const username = $('authUsername').value.trim();
  const password = $('authPassword').value;
  if (!username || !password) { authUI.showLogin('نام کاربری و رمز عبور را وارد کنید.'); return; }
  $('loginButton').disabled = true;
  $('loginButton').textContent = 'در حال بررسی…';
  $('authMessage').textContent = '';
  const [activeTab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!activeTab?.id || !/^https:\/\/(www\.)?raja\.ir\//i.test(activeTab.url || '')) {
    $('authPassword').value = '';
    authUI.showLogin('برای ورود، ابتدا سایت رجا را در تب موردنظر باز کنید.');
    return;
  }
  const result = await runtimeMessage({type:'AUTH_LOGIN', username, password, tabId:activeTab.id});
  $('authPassword').value = '';
  if (result?.ok && result.valid) {
    authUI.showApp(result.username || username);
  } else {
    authUI.showLogin(result?.message || 'ورود انجام نشد؛ اطلاعات را بررسی کنید.');
  }
});
$('authPassword').addEventListener('keydown', e => { if (e.key === 'Enter') $('loginButton').click(); });
$('logoutButton').addEventListener('click', async () => {
  const [activeTab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!activeTab?.id || !/^https:\/\/(www\.)?raja\.ir\//i.test(activeTab.url || '')) {
    authUI.showLogin('برای خروج، به تب مالک در سایت رجا برگردید.');
    return;
  }
  const result = await runtimeMessage({type:'AUTH_LOGOUT',tabId:activeTab.id});
  if (result?.ok) authUI.showLogin(result.message || 'از حساب خارج شدید.');
  else $('authMessage').textContent = result?.message || 'خروج از حساب انجام نشد.';
});

const toLatin = s => String(s||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const toFa = s => String(s).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
function parseJalali(raw){const v=toLatin(raw).trim().replace(/[.\-]/g,'/');const m=v.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);if(!m)return null;const year=+m[1],month=+m[2],day=+m[3];if(year<1300||year>1500||month<1||month>12||day<1||day>(month<=6?31:month<=11?30:30))return null;const g=jalaliToGregorian(year,month,day);if(!g)return null;return {formatted:`${year}/${String(month).padStart(2,'0')}/${String(day).padStart(2,'0')}`,gregorian:`${g[0]}-${String(g[1]).padStart(2,'0')}-${String(g[2]).padStart(2,'0')}`};}
function jalaliToGregorian(jy,jm,jd){jy-=979;let jdn=365*jy+Math.floor(jy/33)*8+Math.floor((jy%33+3)/4);for(let i=1;i<jm;i++)jdn+=(i<=6?31:30);jdn+=jd-1;let gdn=jdn+79;let gy=1600+400*Math.floor(gdn/146097);gdn%=146097;let leap=true;if(gdn>=36525){gdn--;gy+=100*Math.floor(gdn/36524);gdn%=36524;if(gdn>=365)gdn++;else leap=false;}gy+=4*Math.floor(gdn/1461);gdn%=1461;if(gdn>=366){leap=false;gdn--;gy+=Math.floor(gdn/365);gdn%=365;}const sal=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];let gm=0;while(gm<12&&gdn>=sal[gm])gdn-=sal[gm++];return [gy,gm+1,gdn+1];}
function readForm(){const d=parseJalali($('dateJalali').value);return {origin:$('origin').value.trim(),destination:$('destination').value.trim(),dateJalali:d?.formatted||'',dateGregorian:d?.gregorian||'',passengers:$('passengers').value,interval:Number($('interval').value),autofill:$('autofill').checked,autonext:$('autonext').checked,wagonFilter:$('wagonFilter').value,trainCompany:$('trainCompany').value.trim(),starFilter:$('starFilter').value,minPrice:toLatin($('minPrice').value).replace(/[^0-9]/g,''),maxPrice:toLatin($('maxPrice').value).replace(/[^0-9]/g,''),availableOnly:$('availableOnly').checked,autoSelectTrain:$('autoSelectTrain').checked};}
function applyForm(s){$('origin').value=s.origin??defaults.origin;$('destination').value=s.destination??defaults.destination;$('dateJalali').value=toFa((s.dateJalali||defaults.dateJalali).replace(/-/g,'/'));$('passengers').value=s.passengers??defaults.passengers;$('interval').value=Math.min(30,Math.max(5,Number(s.interval??defaults.interval)||5));$('autofill').checked=s.autofill??defaults.autofill;$('autonext').checked=s.autonext??defaults.autonext;$('wagonFilter').value=s.wagonFilter??defaults.wagonFilter;$('trainCompany').value=s.trainCompany??defaults.trainCompany;$('starFilter').value=s.starFilter??defaults.starFilter;$('minPrice').value=s.minPrice??defaults.minPrice;$('maxPrice').value=s.maxPrice??defaults.maxPrice;$('availableOnly').checked=s.availableOnly??defaults.availableOnly;$('autoSelectTrain').checked=s.autoSelectTrain??defaults.autoSelectTrain;$('intervalValue').textContent=toFa($('interval').value);}
function addPassengerRow(profile={}){const root=$('profiles');const idx=root.children.length+1;const card=document.createElement('div');card.className='passenger-card';card.innerHTML=`<div class="passenger-title"><strong>مسافر ${toFa(idx)}</strong><button class="remove-passenger" type="button" aria-label="حذف مسافر">حذف</button></div><div class="passenger-grid"><label>نام<input data-field="firstName" type="text" autocomplete="off"></label><label>نام خانوادگی<input data-field="lastName" type="text" autocomplete="off"></label><label>کد ملی / پاسپورت<input data-field="nationalId" type="text" inputmode="numeric" autocomplete="off"></label><label>تاریخ تولد شمسی<div class="date-row birth-date-row"><input data-field="birthDate" type="text" placeholder="۱۳۷۰/۰۱/۱۵" autocomplete="off"><button class="secondary calendar-trigger birth-calendar-trigger" type="button">تقویم</button></div></label></div>`;for(const [key,val] of Object.entries(profile||{})){const input=card.querySelector(`[data-field="${key}"]`);if(input)input.value=val||'';}card.querySelector('.remove-passenger').addEventListener('click',()=>{if(root.children.length<=1){$('profileMessage').textContent='حداقل یک ردیف مسافر نگه دارید؛ می‌توانید اطلاعات آن را خالی بگذارید.';return;}card.remove();renumberPassengers();});card.querySelector('.birth-calendar-trigger').addEventListener('click',()=>{calendarTarget=card.querySelector('[data-field="birthDate"]');currentCalendarFromInput(calendarTarget);renderCalendar(calendarTarget);$('jalaliCalendar').hidden=false;});card.querySelector('[data-field="birthDate"]').addEventListener('blur',e=>{const d=parseJalali(e.target.value);if(d)e.target.value=toFa(d.formatted);});root.appendChild(card);renumberPassengers();refreshPassengerCount();}
function renumberPassengers(){[...$('profiles').children].forEach((card,i)=>card.querySelector('strong').textContent=`مسافر ${toFa(i+1)}`);}
function refreshPassengerCount(){const select=$('passengers');const current=select.value||'1';select.innerHTML='';for(let i=1;i<=6;i++){const op=document.createElement('option');op.value=String(i);op.textContent=toFa(i);select.appendChild(op);}select.value=String(Math.min(6,Math.max(1,Number(current)||1)));}
function readProfiles(){return [...$('profiles').children].map(card=>Object.fromEntries([...card.querySelectorAll('[data-field]')].map(input=>[input.dataset.field,input.value.trim()]))).filter(p=>p.firstName||p.lastName||p.nationalId||p.birthDate);}
function applyProfiles(profiles){$('profiles').innerHTML='';const list=Array.isArray(profiles)&&profiles.length?profiles:[{}];list.forEach(p=>addPassengerRow(p));}
let intervalUpdateTimer;
$('interval').addEventListener('input',()=> {
  const seconds=Math.max(5,Math.min(30,Number($('interval').value)||5));
  $('intervalValue').textContent=toFa(seconds);
  clearTimeout(intervalUpdateTimer);
  intervalUpdateTimer=setTimeout(async()=>{
    try {
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      const result=await chrome.runtime.sendMessage({
        type:'UPDATE_INTERVAL',
        interval:seconds,
        tabId:tab?.id
      });
      if(!result?.ok && result?.message) $('message').textContent=result.message;
    } catch {
      $('message').textContent='تغییر فاصله بررسی ثبت نشد؛ مالکیت تب را بررسی کنید.';
    }
  },80);
});$('dateJalali').addEventListener('blur',()=>{const d=parseJalali($('dateJalali').value);if(d)$('dateJalali').value=toFa(d.formatted);});$('addPassenger').addEventListener('click',()=>addPassengerRow());
// Interactive Jalali calendar, using the same Jalali/Gregorian conversion as validation.
let calYear=1405, calMonth=1, calendarTarget=$('dateJalali');
function jalaliMonthLength(y,m){if(m<=6)return 31;if(m<=11)return 30;const a=jalaliToGregorian(y,12,1),b=jalaliToGregorian(y+1,1,1);return Math.round((Date.UTC(b[0],b[1]-1,b[2])-Date.UTC(a[0],a[1]-1,a[2]))/86400000);}
function currentCalendarFromInput(target=calendarTarget){calendarTarget=target||$('dateJalali');const d=parseJalali(calendarTarget.value);if(d){const a=d.formatted.split('/').map(Number);calYear=a[0];calMonth=a[1];}else{calYear=1405;calMonth=1;}}
const calMonthSelect=$('calMonthSelect'),calYearSelect=$('calYearSelect');
const jalaliMonths=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
for(let m=1;m<=12;m++){const o=document.createElement('option');o.value=String(m);o.textContent=jalaliMonths[m-1];calMonthSelect.appendChild(o);}
for(let y=1300;y<=1500;y++){const o=document.createElement('option');o.value=String(y);o.textContent=toFa(y);calYearSelect.appendChild(o);}
function renderCalendar(target=calendarTarget){if(target)calendarTarget=target;calMonthSelect.value=String(calMonth);calYearSelect.value=String(calYear);const days=$('calDays');days.innerHTML='';const first=jalaliToGregorian(calYear,calMonth,1);const weekday=(new Date(first[0],first[1]-1,first[2]).getDay()+1)%7;for(let i=0;i<weekday;i++){const blank=document.createElement('span');blank.className='empty';days.appendChild(blank);}const selected=parseJalali(calendarTarget.value)?.formatted;for(let day=1;day<=jalaliMonthLength(calYear,calMonth);day++){const b=document.createElement('button');b.type='button';b.textContent=toFa(day);const value=`${calYear}/${String(calMonth).padStart(2,'0')}/${String(day).padStart(2,'0')}`;if(value===selected)b.classList.add('selected');b.addEventListener('click',()=>{calendarTarget.value=toFa(value);calendarTarget.dispatchEvent(new Event('change',{bubbles:true}));calendarTarget.dispatchEvent(new Event('input',{bubbles:true}));$('jalaliCalendar').hidden=true;});days.appendChild(b);}}
$('openCalendar').addEventListener('click',()=>{currentCalendarFromInput($('dateJalali'));renderCalendar($('dateJalali'));$('jalaliCalendar').hidden=!$('jalaliCalendar').hidden;});$('calPrev').addEventListener('click',()=>{if(--calMonth<1){calMonth=12;calYear--;}renderCalendar();});$('calNext').addEventListener('click',()=>{if(++calMonth>12){calMonth=1;calYear++;}renderCalendar();});calMonthSelect.addEventListener('change',()=>{calMonth=Number(calMonthSelect.value);renderCalendar();});calYearSelect.addEventListener('change',()=>{calYear=Number(calYearSelect.value);renderCalendar();});$('calClose').addEventListener('click',()=>{$('jalaliCalendar').hidden=true;});
chrome.storage.local.get(['settings','profiles','profile','contactPhone','bookingWorkflow'],data=>{applyForm({...defaults,...(data.settings||{})});const profiles=data.profiles?.length?data.profiles:(data.profile?[data.profile]:[{}]);applyProfiles(profiles);$('phone').value=data.contactPhone||profiles[0]?.phone||'';const flow=data.bookingWorkflow;if(flow?.active)updateState(true,'رزرو در حال اجراست؛ مراحل بعدی خودکار ادامه پیدا می‌کنند.');});
async function saveAll(){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!/^https:\/\/(www\.)?raja\.ir\//.test(tab.url||'')){$('message').textContent='برای ذخیره تنظیمات، ابتدا سایت رجا را در تب مالک باز کنید.';return false;}const auth=await runtimeMessage({type:'AUTH_STATUS',tabId:tab.id});if(!auth?.valid){authUI.showLogin(auth?.message||'برای ادامه وارد شوید.');return false;}const owner=await runtimeMessage({type:'CHECK_OWNER',tabId:tab.id});if(!owner?.ok){$('message').textContent=owner?.message||'فقط تب مالک حساب می‌تواند تنظیمات را ذخیره کند.';return false;}const settings=readForm();if(!settings.dateJalali){$('message').textContent='تاریخ شمسی معتبر وارد کنید؛ مثال ۱۴۰۵/۰۷/۲۸.';return false;}const profiles=readProfiles();const contactPhone=$('phone').value.trim();const saved=await chrome.runtime.sendMessage({type:'SAVE_SETTINGS',tabId:tab.id,settings,profiles,contactPhone});if(!saved?.ok){$('message').textContent=saved?.message||'ذخیره تنظیمات انجام نشد.';return false;}return true;}
function updateState(running,message){$('start').disabled=running;$('stop').disabled=!running;$('status').textContent=running?'در حال رزرو':'آماده';$('start').textContent=running?'مراحل در حال اجرا…':'شروع رزرو خودکار';if(message)$('message').textContent=message;}
$('save').addEventListener('click',async()=>{if(await saveAll())$('message').textContent=`تنظیمات ذخیره شد. تاریخ میلادی معادل: ${readForm().dateGregorian}`;});
$('saveProfiles').addEventListener('click',async()=>{const ok=await saveAll();if(ok)$('profileMessage').textContent=`${readProfiles().length} پروفایل ذخیره شد. اطلاعات فقط در همین مرورگر نگهداری می‌شود.`;});
async function send(action){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!/^https:\/\/(www\.)?raja\.ir\//.test(tab.url||'')){$('message').textContent='ابتدا سایت raja.ir را در همین تب باز کنید.';return;}try{const settings=readForm();if(action==='START'){const flow=await chrome.runtime.sendMessage({type:'START_WORKFLOW',tabId:tab.id,settings});if(!flow?.ok){$('message').textContent=flow?.message||'شروع فرایند ثبت نشد.';return;}updateState(true,'رزرو آغاز شد؛ در حال اجرای مرحله فعلی…');}const response=await chrome.tabs.sendMessage(tab.id,{type:action,settings});if(response?.message)$('message').textContent=response.message;if(action==='START'&&response?.ok)updateState(true,response.message||'فرایند در حال اجراست.');}catch(error){$('message').textContent='ارتباط با صفحه برقرار نشد؛ صفحه رجا را تازه‌سازی کنید و دوباره امتحان کنید.';}}
$('start').addEventListener('click',async()=>{const settings=readForm();if(!settings.origin||!settings.destination||!settings.dateJalali){$('message').textContent='مبدأ، مقصد و تاریخ شمسی معتبر را کامل کنید.';return;}const profiles=readProfiles();if(settings.autofill&&profiles.length<Number(settings.passengers)){$('message').textContent=`تعداد پروفایل‌های ذخیره‌شده (${profiles.length}) از تعداد مسافران انتخابی (${settings.passengers}) کمتر است.`;return;}if(!await saveAll())return;send('START');});
$('stop').addEventListener('click',async()=>{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id){$('message').textContent='تب فعال شناسایی نشد.';return;}const r=await chrome.runtime.sendMessage({type:'STOP_FLOW',tabId:tab.id});if(!r?.ok){$('message').textContent=r?.message||'توقف فرایند انجام نشد.';return;}updateState(false,r.message||'فرایند متوقف شد.');});
$('dateJalali').value=toFa($('dateJalali').value);refreshPassengerCount();
chrome.runtime.onMessage.addListener(msg=>{if(msg.type==='STATUS'||msg.type==='UI_STATUS')updateState(!!msg.running,msg.message);});

refreshAuth();
